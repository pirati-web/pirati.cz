'use strict';

var gulp        = require('gulp'),
    sass        = require('./tasks/sass.js')(),
    scripts     = require('./tasks/scripts.js')(),
    purifycss   = require('./tasks/purifycss.js')(),
    browserSync = require('./tasks/browser-sync.js')(),
    twig        = require('./tasks/twig.js')(),
    twigPartials= require('./tasks/twig-partials.js')(),
    imagemin    = require('./tasks/imagemin.js')(),
    spritesmith = require('./tasks/spritesmith.js')(),
    a11y        = require('./tasks/a11y.js')();

gulp.task('default', [
  'browser-sync',
  'sass:watch',
  'scripts:watch',
  /* 'purifycss:watch', */
  'twig:watch',
  /* 'twig-partials:watch', */
  /* 'imagemin:watch', */
  'spritesmith:watch'
]);