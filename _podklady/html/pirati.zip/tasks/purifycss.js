'use strict';

var gulp          = require('gulp'),
    gulpPurifycss = require('gulp-purifycss'),
    browserSync   = require('browser-sync');

module.exports = () => {
  gulp.task('purifycss', () => {
    return gulp.src('./dist/styles/*.css')
      .pipe(gulpPurifycss(['./dist/scripts/**/*.js', './dist/*.html']))
      .pipe(gulp.dest('./dist/styles/'))
      .pipe(browserSync.stream());
  });

  gulp.task('purifycss:watch', () => {
    gulp.watch('./dist/styles/*.css', ['purifycss']);
  });
};