'use strict';

var gulp              = require('gulp'),
    gulpSass          = require('gulp-sass'),
    gulpSourcemaps    = require('gulp-sourcemaps'),
    gulpAutoprefixer  = require('gulp-autoprefixer'),
    browserSync       = require('browser-sync');

module.exports = () => {
  gulp.task('sass', () => {
    return gulp.src('./src/styles/main.scss')
      /* .pipe(gulpSourcemaps.init({ loadMaps: true })) */
      .pipe(gulpSass({
        outputStyle: 'compressed',
        includePaths: ['./node_modules/foundation-sites/scss']
      }).on('error', gulpSass.logError))
      /* .pipe(gulpSourcemaps.write()) */
      .pipe(gulpAutoprefixer({
        browsers: ['last 2 versions', '> 1%', 'Firefox ESR']
      }))
      .pipe(gulp.dest('./dist/styles'))
      .pipe(browserSync.stream());
  });

  gulp.task('sass:watch', () => {
    gulp.watch('./src/styles/**/*.scss', ['sass']);
  });
};