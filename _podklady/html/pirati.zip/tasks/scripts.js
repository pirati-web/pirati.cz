'use strict';

var gulp          = require('gulp'),
    gulpUglify    = require('gulp-uglify'),
    gulpConcat    = require('gulp-concat'),
    gulpPlumber   = require('gulp-plumber'),
    browserSync   = require('browser-sync');

module.exports = () => {
  gulp.task('scripts', () => {
    return gulp.src(['./src/scripts/libs/*.js','./src/scripts/*.js'])
      .pipe(gulpPlumber({
        errorHandler: (error) => {
          console.log(error.message);
          this.emit('end');
      }}))
      .pipe(gulpConcat('all.min.js'))
      .pipe(gulpUglify())
      .pipe(gulp.dest('./dist/scripts/'))
      .pipe(browserSync.stream());
  });

  gulp.task('scripts:watch', () => {
    gulp.watch(['./src/scripts/**/*.js'], ['scripts']);
  });
};