'use strict';

var gulp            = require('gulp'),
    gulpImagemin    = require('gulp-imagemin'),
    gulpSpritesmith = require('gulp.spritesmith'),
    browserSync     = require('browser-sync');

module.exports = () => {
  gulp.task('spritesmith', () => {
    var spriteData =
      gulp.src('./src/sprites/**/*')
        .pipe(gulpSpritesmith({
          imgName: './dist/sprites/sprites.png',
          retinaSrcFilter: '*@2x.png',
          retinaImgName: './dist/sprites/sprites@2x.png',
          cssName: './src/styles/_sprites.scss' // <<-- just need to change this line
        }))
        .pipe(gulpImagemin());
    spriteData.img.pipe(gulp.dest(''));
    spriteData.css.pipe(gulp.dest(''));
  });

  gulp.task('spritesmith:watch', () => {
    gulp.watch('./src/sprites/**/*', ['spritesmith']);
  });
};